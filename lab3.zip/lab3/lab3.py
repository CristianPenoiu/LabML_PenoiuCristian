from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import tkinter as tk
from tkinter import scrolledtext

# Load the dataset
data_path = 'C:\\Users\\cristi\\Desktop\\An4_sem1\\ML_Lab\\lab3\\ecommerceDataset.csv'
data = pd.read_csv(data_path)

# Rename columns for easier access and inspect the structure
data.columns = ["Category", "Description"]

# Remove rows with NaN values in 'Description' column
data = data.dropna(subset=['Description'])

# Split the dataset into features and target labels
X = data['Description']
y = data['Category']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Vectorize the text data
tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Initialize classifiers
nb_model = MultinomialNB()
dt_model = DecisionTreeClassifier(random_state=42)

# Train and test Naive Bayes
nb_model.fit(X_train_tfidf, y_train)
nb_predictions = nb_model.predict(X_test_tfidf)
nb_accuracy = accuracy_score(y_test, nb_predictions)

# Train and test Decision Tree
dt_model.fit(X_train_tfidf, y_train)
dt_predictions = dt_model.predict(X_test_tfidf)
dt_accuracy = accuracy_score(y_test, dt_predictions)

# Prepare the results for display
results = f"Naive Bayes Accuracy: {nb_accuracy:.2f}\n"
results += f"Decision Tree Accuracy: {dt_accuracy:.2f}\n\n"
results += "Naive Bayes Classification Report:\n" + classification_report(y_test, nb_predictions) + "\n"
results += "Decision Tree Classification Report:\n" + classification_report(y_test, dt_predictions)

# Display the results in a GUI window
root = tk.Tk()
root.title("Classification Results")

# Create a scrolled text widget to show results
text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=100, height=30, font=("Helvetica", 10))
text_area.pack(padx=10, pady=10)
text_area.insert(tk.INSERT, results)
text_area.config(state="disabled")  # Make the text read-only

# Run the GUI loop
root.mainloop()
